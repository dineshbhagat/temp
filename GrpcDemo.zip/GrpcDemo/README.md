## Micronaut 3.9.1 Documentation

- [User Guide](https://docs.micronaut.io/3.9.1/guide/index.html)
- [API Reference](https://docs.micronaut.io/3.9.1/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/3.9.1/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)

---

- [Protobuf Gradle Plugin](https://plugins.gradle.org/plugin/com.google.protobuf)
- [Micronaut Gradle Plugin documentation](https://micronaut-projects.github.io/micronaut-gradle-plugin/latest/)
- [GraalVM Gradle Plugin documentation](https://graalvm.github.io/native-build-tools/latest/gradle-plugin.html)
- [Shadow Gradle Plugin](https://plugins.gradle.org/plugin/com.github.johnrengelman.shadow)

### Grpc ref

- https://grpc.io/docs/what-is-grpc/introduction/   
- https://grpc.io/docs/languages/java/
- https://grpc.io/docs/languages/kotlin/
- https://micronaut-projects.github.io/micronaut-grpc/latest/guide/
- https://www.baeldung.com/google-protocol-buffer
- https://www.baeldung.com/grpcs-error-handling
- https://www.baeldung.com/java-grpc-streaming
- https://docs.insomnia.rest/insomnia/grpc
- https://stackoverflow.com/q/48748745/2987755

![](images/Insomnia-Requests.png)


Note BD prefix before method, and tab name as show [here](images/Insomnia-Requests.png)

Positive Scenario:   
- client request ![](images/ClientRequest.png)
- start the client connection ![start the client](images/startConnection.png)
- send multiple data streams ![](images/stream1.png), ![](images/stream2.png)
- close the connection if not required with "commit"
- observe multiple stream requests and responses

Error Scenario:   
- Start the client but do not stream any data ![](images/errorScenario-start.png)
- end the client with "commit" ![](images/errorScenario-end.png)
- as you can observe response code with message, which we have configured at file GrpcChatServiceImpl.kt .onEmpty block