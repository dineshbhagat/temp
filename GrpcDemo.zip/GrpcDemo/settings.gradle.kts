
rootProject.name="GrpcDemo"

val kotlinVersion="1.8.21"
