//package com.demo.server
//
//import com.baeldung.grpc.errorhandling.CommodityServer.CommodityService
//import com.demo.ErrorResponse
//import com.demo.GrpcDemoRequest
//import com.demo.GrpcDemoServiceGrpc
//import io.grpc.Status
//import io.grpc.StatusRuntimeException
//import io.grpc.inprocess.InProcessChannelBuilder
//import io.grpc.inprocess.InProcessServerBuilder
//import io.grpc.protobuf.ProtoUtils
//import io.kotest.core.spec.style.AnnotationSpec
//import org.junit.jupiter.api.Assertions
//import org.junit.jupiter.api.Assertions.assertEquals
//import org.junit.jupiter.api.BeforeEach
//import org.junit.jupiter.api.Test
//
//class GrpcDemoServiceImplTest : AnnotationSpec() {
//    var blockingStub: GrpcDemoServiceGrpc.GrpcDemoServiceBlockingStub? = null
//    @BeforeEach
//    @Throws(java.lang.Exception::class)
//    fun setup() {
//        val serverName: String = InProcessServerBuilder.generateName()
//        grpcCleanup.register(
//            InProcessServerBuilder.forName(serverName)
//                .directExecutor()
//                .addService(GrpcDemoServiceGrpc())
//                .build()
//                .start()
//        )
//        blockingStub = CommodityPriceProviderGrpc.newBlockingStub(
//            grpcCleanup.register(
//                InProcessChannelBuilder.forName(serverName)
//                    .directExecutor()
//                    .build()
//            )
//        )
//    }
//
//    @Test
//    @Throws(Exception::class)
//    fun whenUsingInvalidCommodityName_thenReturnExceptionIoRpcStatus() {
//        val request = GrpcDemoRequest.newBuilder()
//            .setName("AA")
//            .build()
//        val thrown = Assertions.assertThrows<StatusRuntimeException>(
//            StatusRuntimeException::class.java
//        ) { blockingStub.getBestCommodityPrice(request) }
//        assertEquals("INVALID_ARGUMENT", thrown.status.code.toString())
//        assertEquals("INVALID_ARGUMENT: The commodity is not supported", thrown.message)
//        val metadata = Status.trailersFromThrowable(thrown)
//        val errorResponse: ErrorResponse = metadata.get(ProtoUtils.keyForProto(ErrorResponse.getDefaultInstance()))
//        assertEquals("Commodity5", errorResponse.getCommodityName())
//        assertEquals("123validToken", errorResponse.getAccessToken())
//        assertEquals("Only Commodity1, Commodity2 are supported", errorResponse.getExpectedValue())
//    }
//}