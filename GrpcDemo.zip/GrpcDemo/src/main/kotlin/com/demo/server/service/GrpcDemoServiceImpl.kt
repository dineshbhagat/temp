package com.demo.server.service

import com.demo.ErrorResponse
import com.demo.GrpcDemoReply
import com.demo.GrpcDemoRequest
import com.demo.GrpcDemoServiceGrpcKt
import io.grpc.Metadata
import io.grpc.Status.INVALID_ARGUMENT
import io.grpc.protobuf.ProtoUtils
import jakarta.inject.Singleton
import org.slf4j.LoggerFactory

/**
 * We need to provide an implementation to GrpcDemoService mentioned in grpcDemo.proto file
 * Ref: https://www.baeldung.com/java-grpc-streaming
 *
 */
@Singleton
class GrpcDemoServiceImpl : GrpcDemoServiceGrpcKt.GrpcDemoServiceCoroutineImplBase() {

    companion object {
        private val log = LoggerFactory.getLogger(this::class.java)
    }

    override suspend fun hello(request: GrpcDemoRequest): GrpcDemoReply {
        log.info("Request received $request")
        val name = request.name
        if (name.isNullOrBlank()) {
            val errorResponse = ErrorResponse.newBuilder().setStatus("400").setErrorMessage("enter valid name").build()
            val asRuntimeException = INVALID_ARGUMENT
                .withDescription("Null or empty name is not supported")
                .asRuntimeException(Metadata()
                    .also { ProtoUtils.keyForProto(ErrorResponse.getDefaultInstance()) to errorResponse }
                )
            /* this onError method will terminate connection between server and
               client which is not desirable for stream,
               so we need to handle differently for stream grpc calls than this unary grpc calls
               responseObserver?.onError(asRuntimeException)
             */
            throw asRuntimeException
        }
        val message = "Hello $name"
        return GrpcDemoReply.newBuilder().setMessage(message).build()
    }
}