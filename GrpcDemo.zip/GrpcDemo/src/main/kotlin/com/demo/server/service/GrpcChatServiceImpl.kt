package com.demo.server.service

import com.demo.ChatReply
import com.demo.ChatRequest
import com.demo.ErrorResponse
import com.demo.GrpcChatServiceGrpcKt
import io.grpc.Metadata
import io.grpc.Status
import io.grpc.protobuf.ProtoUtils
import jakarta.inject.Singleton
import java.time.LocalDateTime
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEmpty
import kotlinx.coroutines.flow.onStart
import org.slf4j.LoggerFactory

/**
 * Ref: https://stackoverflow.com/q/48748745/2987755
 *
 */
@Singleton
class GrpcChatServiceImpl : GrpcChatServiceGrpcKt.GrpcChatServiceCoroutineImplBase() {

    companion object {
        private val log = LoggerFactory.getLogger(this::class.java)
    }

    private val messageCounter = AtomicInteger(0)
    val start = System.currentTimeMillis()

    override fun chat(requests: Flow<ChatRequest>): Flow<ChatReply> {
        return requests
            .onStart {
                log.info("chat started ...")
            }
            .onEmpty {
                val errorResponse =
                    ErrorResponse.newBuilder().setStatus("400").setErrorMessage("enter valid message").build()
                val asRuntimeException = Status.FAILED_PRECONDITION
                    .withDescription("Null or empty request is not supported")
                    .asRuntimeException(
                        Metadata()
                            .also { ProtoUtils.keyForProto(ErrorResponse.getDefaultInstance()) to errorResponse }
                    )
                throw asRuntimeException
            }
            .onCompletion { log.info("total chat duration ...${(System.currentTimeMillis()-start)/1000} sec") }
//            .catch { log.error("Exception occurred message: ${it.message} ${it.localizedMessage}") }
            .map {
                val message = it.message
                if (message.isNullOrBlank()) {
                    // one can decide whether we need to end connection once we receive
                    // any invalid input, or we need to continue...
                    val errorResponse =
                        ErrorResponse.newBuilder().setStatus("400").setErrorMessage("enter valid message").build()
                    val asRuntimeException = Status.INVALID_ARGUMENT
                        .withDescription("Null or empty message is not supported")
                        .asRuntimeException(
                            Metadata()
                                .also { ProtoUtils.keyForProto(ErrorResponse.getDefaultInstance()) to errorResponse }
                        )
                    return@map ChatReply
                        .newBuilder().build()
                }
                ChatReply
                    .newBuilder()
                    .setMessage(
                        "$message received," +
                                " message: ${messageCounter.incrementAndGet()}," +
                                " time: ${LocalDateTime.now()}"
                    )
                    .build()
            }
    }

}