package com.demo

import com.demo.GrpcDemoServiceGrpc.GrpcDemoServiceImplBase
import io.grpc.Server
import io.grpc.ServerBuilder
import io.micronaut.runtime.Micronaut.run


fun main(args: Array<String>) {
	run(*args)
}

